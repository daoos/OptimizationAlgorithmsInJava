package hr.fer.zemris.optjava.dz4;

public interface ISelection {

	public DoubleArraySolution Selection(DoubleArraySolution[] d);

	DoubleArraySolution Selection(DoubleArraySolution[] d, boolean b); 
	
}
