package hr.fer.zemris.optjava.dz4;

public interface IFunction {

	public double valueAt(double[] d);
	
}
