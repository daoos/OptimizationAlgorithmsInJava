package hr.fer.zemris.optjava.dz4;

public interface ICrossing {

	DoubleArraySolution cross(DoubleArraySolution p1, DoubleArraySolution p2);
	
}
