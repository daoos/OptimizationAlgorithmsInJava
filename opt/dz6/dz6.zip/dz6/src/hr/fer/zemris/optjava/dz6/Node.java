package hr.fer.zemris.optjava.dz6;

public class Node {

	double[] values=null;
	public Node(double d1,double d2) {
		values = new double[2];
		values[0] =d1;
		values[1] =d2;
	}

}
